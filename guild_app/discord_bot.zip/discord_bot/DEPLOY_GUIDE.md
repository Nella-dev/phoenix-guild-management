# 🤖 ROIDER Discord Bot — 배포 가이드

## 1단계 · Discord 봇 생성 (Discord Developer Portal)

1. https://discord.com/developers/applications 접속
2. **New Application** → 이름: `ROIDER Bot` (아무 이름)
3. 왼쪽 메뉴 **Bot** 탭
   - **Reset Token** → 토큰 복사해 두기 (`.env`의 `DISCORD_BOT_TOKEN`)
   - **Privileged Gateway Intents** 섹션에서 **Message Content Intent** ✅ 활성화
4. **OAuth2 → URL Generator**
   - Scopes: `bot`
   - Bot Permissions: `Read Messages/View Channels` + `Read Message History`
   - 생성된 URL로 봇을 **Yaphalla 서버에 초대**

---

## 2단계 · Firebase 서비스 계정 키 발급

1. https://console.firebase.google.com → `roider-guild-management` 프로젝트
2. ⚙️ 프로젝트 설정 → **서비스 계정** 탭
3. **새 비공개 키 생성** → JSON 파일 다운로드
4. 다운로드한 파일을 `firebase-service-account.json` 이름으로 봇 폴더에 저장

---

## 3단계 · 채널 ID 확인

1. Discord **사용자 설정 → 고급 → 개발자 모드** 활성화
2. 감시할 채널 우클릭 → **ID 복사**
3. 여러 채널이면 쉼표로 구분

---

## 4단계 · .env 파일 설정

```env
DISCORD_BOT_TOKEN=여기에_봇_토큰_붙여넣기
WATCH_CHANNEL_IDS=채널ID1,채널ID2
FIREBASE_SERVICE_ACCOUNT_PATH=./firebase-service-account.json
FIREBASE_PROJECT_ID=roider-guild-management
FIRESTORE_COLLECTION=infographic_posts
IGNORE_BOT_MESSAGES=true
MAX_IMAGES_PER_POST=10
```

---

## 5단계 · 로컬 테스트

```bash
cd discord_bot
npm install
node bot.js
# → "✅ Logged in as ROIDER Bot#XXXX" 출력되면 성공
```

---

## 6단계 · Railway 무료 배포 (상시 실행)

### 6-1. Railway 가입
https://railway.app → GitHub 계정으로 로그인

### 6-2. 프로젝트 생성
1. **New Project → Deploy from GitHub repo**
2. `discord_bot` 폴더를 별도 GitHub 레포로 push
   ```bash
   cd discord_bot
   git init
   git add .
   # ⚠️ .gitignore에 .env, firebase-service-account.json 반드시 포함!
   git commit -m "initial"
   git remote add origin https://github.com/YOUR_USER/roider-discord-bot.git
   git push -u origin main
   ```
3. Railway에서 해당 레포 선택

### 6-3. 환경변수 설정 (Railway 대시보드)
- `DISCORD_BOT_TOKEN` = 봇 토큰
- `WATCH_CHANNEL_IDS` = 채널 ID
- `FIREBASE_PROJECT_ID` = roider-guild-management
- `FIREBASE_SERVICE_ACCOUNT_JSON` = firebase-service-account.json 파일 내용 전체를 **한 줄 JSON 문자열**로
  ```
  {"type":"service_account","project_id":"roider-guild-management", ...전체 내용... }
  ```
- `FIRESTORE_COLLECTION` = infographic_posts
- `IGNORE_BOT_MESSAGES` = true

### 6-4. 배포 확인
Railway 로그에서 `✅ Logged in as ...` 확인

---

## 7단계 · Firestore 복합 인덱스 생성

웹앱이 `visible == true` + `orderBy createdAt desc` 쿼리를 사용하므로
아래 인덱스가 필요합니다:

1. Firebase Console → Firestore → **인덱스** 탭
2. **복합 인덱스 추가**
   - 컬렉션: `infographic_posts`
   - 필드1: `visible` (오름차순)
   - 필드2: `createdAt` (내림차순)
3. 저장 → 빌드 완료까지 1~2분 대기

> ℹ️ 웹앱 처음 접속 시 콘솔에 인덱스 생성 링크가 자동으로 뜨기도 합니다.

---

## 동작 흐름 요약

```
감시 채널에 글 올라옴
       ↓
Discord Bot 감지 (MessageCreate 이벤트)
       ↓
메시지 파싱:
  - 텍스트, 작성자, 역할, 아바타
  - 첨부 이미지 URL
  - Discord Embed (서버 카드 등)
  - 자동 태그 (epic/rare/영웅이름)
       ↓
Firestore infographic_posts/{messageId} 저장
       ↓
웹앱 onSnapshot 수신 (수초 이내)
       ↓
yaphalla_infographics.html 카드 자동 렌더링 ✅
```

---

## 메시지 수정/삭제 처리

| Discord 이벤트 | 봇 동작 |
|---|---|
| 메시지 수정 | Firestore 문서 `content`, `embeds`, `imageUrls` 업데이트 |
| 메시지 삭제 | `visible: false` → 웹앱에서 숨김 (데이터는 보존) |

---

## Firestore에서 수동 관리

Firebase Console → Firestore → `infographic_posts` 컬렉션

| 필드 | 설명 |
|---|---|
| `visible: false` | 웹앱에서 해당 포스트 숨김 |
| `featured: true` | ⭐ 고정 포스트로 상단 표시 |
| `tags` 배열 | 수동으로 태그 추가/제거 가능 |
