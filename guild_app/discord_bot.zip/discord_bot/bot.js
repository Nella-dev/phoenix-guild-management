// ══════════════════════════════════════════════════════════════════
//  ROIDER Discord Bot — bot.js  (심플 버전)
//  Discord 채널 메시지 → Firebase Firestore 자동 저장
//  개입 0 — 봇이 알아서 다 함
// ══════════════════════════════════════════════════════════════════

require('dotenv').config();
const { Client, GatewayIntentBits, Events } = require('discord.js');
const admin = require('firebase-admin');

// ── Firebase Admin 초기화 ─────────────────────────────
let serviceAccount;
if (process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
  serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON);
} else {
  serviceAccount = require(process.env.FIREBASE_SERVICE_ACCOUNT_PATH || './firebase-service-account.json');
}

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  projectId: process.env.FIREBASE_PROJECT_ID || 'roider-guild-management'
});

const db = admin.firestore();
const COLLECTION = process.env.FIRESTORE_COLLECTION || 'infographic_posts';

// ── 감시 채널 설정 ────────────────────────────────────
const WATCH_IDS = (process.env.WATCH_CHANNEL_IDS || '')
  .split(',').map(s => s.trim()).filter(Boolean);

console.log('🤖 ROIDER Bot 시작...');
console.log('📡 감시 채널:', WATCH_IDS.length > 0 ? WATCH_IDS : '(설정 없음 — 모든 채널)');

// ── Discord Client ────────────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,  // Developer Portal에서 활성화 필요
  ]
});

// ── 이미지 URL 추출 (첨부 + embed) ───────────────────
function extractImageUrls(message) {
  const urls = [];

  // 첨부파일 이미지
  message.attachments.forEach(a => {
    if (a.contentType && a.contentType.startsWith('image/')) {
      urls.push(a.url);
    } else if (/\.(png|jpg|jpeg|gif|webp)$/i.test(a.name || '')) {
      urls.push(a.url);
    }
  });

  // Embed 이미지 (서버 카드 썸네일 등)
  message.embeds.forEach(e => {
    if (e.image?.url)     urls.push(e.image.url);
    if (e.thumbnail?.url) urls.push(e.thumbnail.url);
  });

  return [...new Set(urls)]; // 중복 제거
}

// ── 새 메시지 이벤트 ─────────────────────────────────
client.on(Events.MessageCreate, async message => {
  // 봇 메시지 무시
  if (message.author.bot) return;

  // 채널 필터 (설정된 경우만)
  if (WATCH_IDS.length > 0 && !WATCH_IDS.includes(message.channelId)) return;

  // 내용이 없고 이미지도 없으면 무시
  const imageUrls = extractImageUrls(message);
  if (!message.content && imageUrls.length === 0) return;

  try {
    const data = {
      // 내용
      content:    message.content || '',
      imageUrls,

      // 작성자
      authorName:        message.member?.displayName || message.author.username,
      authorAvatar:      message.author.displayAvatarURL({ size: 128, extension: 'webp' }),

      // 채널
      channelId:   message.channelId,
      channelName: message.channel?.name || '',

      // 출처
      source:      'discord',
      discordMessageId: message.id,

      // 표시 여부
      visible: true,

      // 날짜
      createdAt: admin.firestore.Timestamp.fromDate(message.createdAt),
    };

    await db.collection(COLLECTION).doc(message.id).set(data);
    console.log(`✅ 저장: [#${data.channelName}] ${data.authorName} — 이미지 ${imageUrls.length}개`);

  } catch (err) {
    console.error('❌ 저장 실패:', err.message);
  }
});

// ── 메시지 삭제 → visible:false ───────────────────────
client.on(Events.MessageDelete, async message => {
  if (WATCH_IDS.length > 0 && !WATCH_IDS.includes(message.channelId)) return;
  try {
    await db.collection(COLLECTION).doc(message.id).update({ visible: false });
    console.log(`🗑️ 숨김 처리: ${message.id}`);
  } catch (_) {}
});

// ── 봇 준비 ──────────────────────────────────────────
client.once(Events.ClientReady, c => {
  console.log(`✅ 로그인 완료: ${c.user.tag}`);
});

const token = process.env.DISCORD_BOT_TOKEN;
if (!token) { console.error('❌ DISCORD_BOT_TOKEN 없음!'); process.exit(1); }
client.login(token);
